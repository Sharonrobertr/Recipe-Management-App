import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import "../styles.css"; // Ensure styles.css is correctly imported

const RecipeList = () => {
  const [recipes, setRecipes] = useState([]);
  const [filteredRecipes, setFilteredRecipes] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("All");
  const navigate = useNavigate();

  useEffect(() => {
    axios
      .get("http://localhost:5063/api/recipe") // Ensure backend is running on port 5063
      .then((res) => {
        console.log("API Response:", res.data); // ✅ Debugging: Log response
        setRecipes(res.data);
        setFilteredRecipes(res.data); // Initialize filtered list
      })
      .catch((error) => console.error("Error fetching recipes:", error));
  }, []);

  // ✅ Delete Recipe Function
  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this recipe?")) return;

    try {
      await axios.delete(`http://localhost:5063/api/recipe/${id}`);
      const updatedRecipes = recipes.filter((recipe) => recipe.id !== id);
      setRecipes(updatedRecipes);
      setFilteredRecipes(updatedRecipes); // ✅ Update filtered list
    } catch (error) {
      console.error("Error deleting recipe:", error);
    }
  };

  // ✅ Edit Recipe Function
  const handleEdit = (recipe) => {
    navigate("/add", { state: recipe }); // Redirect to edit page
  };

  // ✅ Category Filter Function
  const handleCategoryChange = (e) => {
    const category = e.target.value;
    setSelectedCategory(category);

    if (category === "All") {
      setFilteredRecipes(recipes);
    } else {
      setFilteredRecipes(recipes.filter((recipe) => recipe.category === category));
    }
  };

  return (
    <div className="recipe-container">
      <h1 className="header">Turn up the heat, unleash your inner chef, and make magic in the kitchen! 🍳</h1>
      <h2>Recipe List</h2>

      {/* ✅ Category Dropdown */}
      <select className="category-filter" value={selectedCategory} onChange={handleCategoryChange}>
        <option value="All">All Categories</option>
        <option value="Breakfast">Breakfast</option>
        <option value="Lunch">Lunch</option>
        <option value="Dinner">Dinner</option>
        <option value="Dessert">Dessert</option>
        <option value="Beverages">Beverages</option>
        <option value="Snacks">Snacks</option>
      </select>

      <Link to="/add">
        <button className="add-recipe-btn">➕ Add New Recipe</button>
      </Link>

      {filteredRecipes.length === 0 ? (
        <p>No recipes available in this category. Add a new one!</p>
      ) : (
        filteredRecipes.map((recipe) => (
          <div key={recipe.id} className="recipe-card">
            {/* ✅ Display Image */}
            <img 
              src={recipe.imageUrl ? `http://localhost:5063${recipe.imageUrl}` : "https://via.placeholder.com/150"} 
              alt={recipe.name} 
              className="recipe-image" 
              onError={(e) => { e.target.src = "https://via.placeholder.com/150"; }} // ✅ If broken link, show placeholder
            />

            <h3 className="recipe-title">{recipe.name}</h3>
            <p className="recipe-category"><strong>Category:</strong> {recipe.category || "Uncategorized"}</p>
            <p className="recipe-details"><strong>Ingredients:</strong> {recipe.ingredients}</p>
            <p className="recipe-details"><strong>Instructions:</strong> {recipe.instructions}</p>

            <button className="edit-btn" onClick={() => handleEdit(recipe)}>✏ Edit</button>
            <button className="delete-btn" onClick={() => handleDelete(recipe.id)}>❌ Delete</button>
          </div>
        ))
      )}
    </div>
  );
};

export default RecipeList;
