import React, { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import axios from "axios";
import "../styles.css"; // Import updated styles

const AddRecipe = () => {
  const location = useLocation(); // Get state (if editing)
  const [recipe, setRecipe] = useState({ 
    name: "", 
    ingredients: "", 
    instructions: "", 
    category: "" // ✅ New category field
  });
  const [image, setImage] = useState(null); // ✅ New state for image file
  const [isEditing, setIsEditing] = useState(false);
  const navigate = useNavigate();

  // ✅ Populate form if editing (from RecipeList.js)
  useEffect(() => {
    if (location.state) {
      setRecipe(location.state);
      setIsEditing(true);
    }
  }, [location.state]);

  const handleChange = (e) => {
    setRecipe({ ...recipe, [e.target.name]: e.target.value });
  };

  const handleImageChange = (e) => {
    setImage(e.target.files[0]); // ✅ Save selected file
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      let response;
      if (isEditing) {
        // ✅ UPDATE EXISTING RECIPE (PUT request)
        response = await axios.put(`http://localhost:5063/api/recipe/${recipe.id}`, recipe);
      } else {
        // ✅ ADD NEW RECIPE (POST request)
        response = await axios.post("http://localhost:5063/api/recipe", recipe);
      }

      const recipeId = response.data.id;

      if (image) {
        // ✅ Upload image separately after creating/updating the recipe
        const formData = new FormData();
        formData.append("file", image);

        await axios.post(`http://localhost:5063/api/recipe/upload-image/${recipeId}`, formData, {
          headers: { "Content-Type": "multipart/form-data" },
        });
      }

      alert(isEditing ? "Recipe updated successfully!" : "Recipe added successfully!");
      navigate("/"); // Redirect to Recipe List
    } catch (error) {
      console.error("Error saving recipe:", error);
      alert("Failed to save recipe. Try again!");
    }
  };

  return (
    <div className="add-recipe-container">
      <h2 className="title">{isEditing ? "Edit Recipe" : "Add Recipe"}</h2>
      <form onSubmit={handleSubmit} className="recipe-form">
        <input type="text" name="name" placeholder="Recipe Name" value={recipe.name} onChange={handleChange} required />
        <textarea name="ingredients" placeholder="Ingredients" value={recipe.ingredients} onChange={handleChange} required />
        <textarea name="instructions" placeholder="Instructions" value={recipe.instructions} onChange={handleChange} required />

        {/* ✅ Category Dropdown */}
        <select name="category" value={recipe.category} onChange={handleChange} required>
          <option value="">Select Category</option>
          <option value="Breakfast">Breakfast</option>
          <option value="Lunch">Lunch</option>
          <option value="Dinner">Dinner</option>
          <option value="Dessert">Dessert</option>
          <option value="Beverages">Beverages</option>
          <option value="Snacks">Snacks</option>
        </select>

        {/* ✅ File Input for Image Upload */}
        <input type="file" accept="image/*" onChange={handleImageChange} />

        <button type="submit" className="add-button">
          <img src="https://plus.unsplash.com/premium_photo-1674666545495-2fd4565afdf3?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="Save" className="button-icon" />
          {isEditing ? "Update Recipe" : "Add Recipe"}
        </button>
      </form>
    </div>
  );
};

export default AddRecipe;
