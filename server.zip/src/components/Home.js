import React from "react";
import { Link } from "react-router-dom";
import "../styles.css"; // Import styles

function Home() {
  return (
    <div className="home-container">
      {/* Hero Section */}
      <div className="hero">
        <h1>Welcome to Culinary Triumph</h1>
      </div>

      {/* Introduction */}
      <p className="home-description">
        Discover, add, and manage your favorite recipes! Cook like a pro.
      </p>

      {/* Feature Cards - Only these will navigate */}
      <div className="feature-container">
        <Link to="/recipes" className="feature-card">
          <img src="https://plus.unsplash.com/premium_photo-1713089366147-d1b18a1e7613?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1yZWxhdGVkfDV8fHxlbnwwfHx8fHw%3D" alt="cooking" />
          <h3>Explore Recipes</h3>
          <p>Find delicious recipes curated for every taste.</p>
        </Link>

        <Link to="/add" className="feature-card">
          <img src="https://plus.unsplash.com/premium_photo-1664374288537-5c97354237eb?q=80&w=2069&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="Cooking" />
          <h3>Create Your Own</h3>
          <p>Add and customize your own favorite recipes.</p>
        </Link>
      </div>
    </div>
  );
}

export default Home;