#pragma warning disable IDE0130 // Namespace does not match folder structure
namespace RecipeApp.Models
#pragma warning restore IDE0130 // Namespace does not match folder structure
{
    public class Recipe
    {
        public int Id { get; set; }
        public string? Name { get; set; }  // Allow null values
        public string? Ingredients { get; set; }
        public string? Instructions { get; set; }
        public string? ImageUrl { get; set; }  // ✅ New field for storing image URL
        public string? Category { get; set; }  // ✅ New field for recipe category
    }
}
