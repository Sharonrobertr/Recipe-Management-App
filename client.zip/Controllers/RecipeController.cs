using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using RecipeApp.Data;
using RecipeApp.Models;
using System;
using System.IO;
using System.Linq;

#pragma warning disable IDE0130 // Namespace does not match folder structure
namespace RecipeApp.Controllers
#pragma warning restore IDE0130 // Namespace does not match folder structure
{
    [Route("api/[controller]")]
    [ApiController]
    public class RecipeController : ControllerBase
    {
        private readonly AppDbContext _context;

        public RecipeController(AppDbContext context)
        {
            _context = context;
        }

        // ✅ Get all recipes (with optional category filter)
        [HttpGet]
        public IActionResult GetRecipes([FromQuery] string? category)
        {
            var recipes = string.IsNullOrEmpty(category) 
                ? _context.Recipes.ToList() 
                : _context.Recipes.Where(r => r.Category == category).ToList();

            return Ok(recipes);
        }

        // ✅ Add a new recipe (with category support)
        [HttpPost]
        public IActionResult AddRecipe([FromBody] Recipe recipe)
        {
            if (recipe == null) return BadRequest();
            _context.Recipes.Add(recipe);
            _context.SaveChanges();
            return Ok(recipe);
        }

        // ✅ Update (Edit) Recipe (with category support)
        [HttpPut("{id}")]
        public IActionResult UpdateRecipe(int id, [FromBody] Recipe updatedRecipe)
        {
            if (id != updatedRecipe.Id) return BadRequest("Recipe ID mismatch.");

            var recipe = _context.Recipes.Find(id);
            if (recipe == null) return NotFound();

            recipe.Name = updatedRecipe.Name;
            recipe.Ingredients = updatedRecipe.Ingredients;
            recipe.Instructions = updatedRecipe.Instructions;
            recipe.ImageUrl = updatedRecipe.ImageUrl; 
            recipe.Category = updatedRecipe.Category; // ✅ Allow category updates

            _context.SaveChanges();
            return Ok(recipe);
        }

        // ✅ Delete Recipe
        [HttpDelete("{id}")]
        public IActionResult DeleteRecipe(int id)
        {
            var recipe = _context.Recipes.Find(id);
            if (recipe == null) return NotFound();

            _context.Recipes.Remove(recipe);
            _context.SaveChanges();
            return NoContent();
        }

        // ✅ Image Upload Endpoint
        [HttpPost("upload-image/{id}")]
        public IActionResult UploadImage(int id, IFormFile file)
        {
            var recipe = _context.Recipes.Find(id);
            if (recipe == null) return NotFound("Recipe not found.");

            if (file == null || file.Length == 0)
                return BadRequest("No file uploaded.");

            var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images");
            if (!Directory.Exists(uploadsFolder))
            {
                Directory.CreateDirectory(uploadsFolder);
            }

            var uniqueFileName = $"{Guid.NewGuid()}_{file.FileName}";
            var filePath = Path.Combine(uploadsFolder, uniqueFileName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                file.CopyTo(stream);
            }

            recipe.ImageUrl = $"/images/{uniqueFileName}";
            _context.SaveChanges();

            return Ok(new { imageUrl = recipe.ImageUrl });
        }
    }
}