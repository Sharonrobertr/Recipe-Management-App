using Microsoft.EntityFrameworkCore;
using RecipeApp.Models;

#pragma warning disable IDE0130 // Namespace does not match folder structure
namespace RecipeApp.Data
#pragma warning restore IDE0130 // Namespace does not match folder structure
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Recipe> Recipes { get; set; }
    }
}